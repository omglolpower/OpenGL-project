#include <iostream>
#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <math.h>
#include <streambuf>
#define LOG(x) std::cout << x << std::endl;
#define PI() 3.14159265

static unsigned int CompileShader(unsigned int type, const std::string & source)
{ //this function will create a shader object and will return its "id"
	unsigned int id = glCreateShader(type);
	const char* src = source.c_str();
	glShaderSource(id, 1, &src, nullptr);
	glCompileShader(id);

	//error handling:

	int result;

	glGetShaderiv(id, GL_COMPILE_STATUS, &result);
	if (result == GL_FALSE)
	{
		int length;
		glGetShaderiv(id, GL_INFO_LOG_LENGTH, &length);
		char* message = (char*)alloca(length * sizeof(char));
		glGetShaderInfoLog(id, length, &length, message);
		std::cout << "Failed to compile " << (type == GL_VERTEX_SHADER ? "vertex" : "fragment")
			<< "shader!" << std::endl;
		std::cout << message << std::endl;
		glDeleteShader(id);
		return 0;
	}

	return id;
}

static int CreateShader(const std::string& vertexShader, const std::string& fragmentShader) //
	// this function will provide opengl with shader source code
{
	unsigned int program = glCreateProgram();


	unsigned int vs = CompileShader(GL_VERTEX_SHADER, vertexShader);
	unsigned int fs = CompileShader(GL_FRAGMENT_SHADER, fragmentShader);

	glAttachShader(program, vs);
	glAttachShader(program, fs);
	glLinkProgram(program);
	glValidateProgram(program);

	glDeleteShader(vs);
	glDeleteShader(fs);

	return program;
}

int main(void)
{
	GLFWwindow* window;

	/* Initialize the library */
	if (!glfwInit())
		return -1;


	/* Create a windowed mode window and its OpenGL context */
	window = glfwCreateWindow(640, 640, "Hello World", NULL, NULL);
	if (!window)
	{
		glfwTerminate();
		return -1;
	}

	/* Make the window's context current */
	glfwMakeContextCurrent(window);

	if (glewInit() != GLEW_OK)
		std::cout << "error" << std::endl;
	std::cout << glGetString(GL_VERSION) << std::endl;

	//circle parameters:
	float scale = 1.0f;
	float radius = 0.5f;
	float positions[1000];
	//coordinates for vertices of triangles:
	for (int i = 0; i < 1000; i++)
	{
		positions[i] = 0.0f;
	}
	float center[2] = { 0.0f, 0.0f };
	positions[0] = center[0];
	positions[1] = center[1];
	for (int i = 0; i < 361; i++)
	{

		positions[(i + 1) * 2] = cos(PI() / 180 * i) * radius * scale;

		positions[2 * (i + 1) + 1] = sin(PI() / 180 * i) * radius * scale;
	}


	unsigned int buffer; //id of buffer
	glGenBuffers(1, &buffer);
	glBindBuffer(GL_ARRAY_BUFFER, buffer);
	glBufferData(GL_ARRAY_BUFFER, sizeof(positions), positions, GL_STATIC_DRAW); //specify the data
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(0,
		2,
		GL_FLOAT,
		GL_FALSE,
		sizeof(float) * 2,
		0);
	std::ifstream ssvs("C:\\dev\\shaders\\BasicVertexShader.txt");
	std::ifstream ssfs("C:\\dev\\shaders\\BasicFragmentShader.txt");
	std::ostringstream ossvs, ossfs;
	ossvs << ssvs.rdbuf();
	std::string vertexShader = ossvs.str();
	ossfs << ssfs.rdbuf();
	std::string fragmentShader = ossfs.str();


	// <---------



	unsigned int shader = CreateShader(vertexShader, fragmentShader);
	glUseProgram(shader);

	/* Loop until the user closes the window */
	while (!glfwWindowShouldClose(window))
	{
		/* Render here */
		glClear(GL_COLOR_BUFFER_BIT);

		glDrawArrays(GL_TRIANGLE_FAN, 0, 1000);



		/* Swap front and back buffers */
		glfwSwapBuffers(window);

		/* Poll for and process events */
		glfwPollEvents();
	}



	glfwTerminate();
	return 0;
}