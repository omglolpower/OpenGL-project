# movement_with_boundaries
Opengl 3.0+, glfw, glew, fment shaders, vtex shaders, move bleaking circle with arrows

a visual studio project should be created using template Default OpenGL project upd4
shaders folder shoud be in C:\\dev
Dependencies folder should be in solution directory
